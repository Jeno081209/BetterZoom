# BetterZoom v2 — 独立的 Flarial 风格缩放模组（LeviLauncher 1.5.16）

一个为 **LeviLauncher 1.5.16**（Minecraft Bedrock **26.40.5 / arm64-v8a**）重新实现的
**独立原生 Zoom 模组**，功能对齐 **Flarial Client** 的 Zoom 模块（含设置面板参数项），
完全基于 Levi 官方 native mod SDK（`pl::` API，来自 preloader-android）与
[BedrockTools](https://github.com/QYCottage/BedrockTools) 风格的字节签名钩子实现，
不依赖 Flarial 本体、不依赖 LeviLauncher 内置 Zoom。

> 之前的 `FlarialZoom v1.3.0` / `ZoomPlus` 为失败品（按钮被注销、Hold/Toggle 缺失、
> 或缺少 `NEEDED libpreloader.so` 导致无法加载），本版本为全新实现。

## 相比 LeviLauncher 内置 Zoom 的改进

| 问题（原版） | BetterZoom v2 |
| --- | --- |
| 缩放动画曲线生硬（线性过渡） | **Flarial 同款指数缓出曲线**（帧率无关，可调速度） |
| 不能滑动调整倍率 | **按住按钮后上下滑动**（或双指）实时调整，松开即恢复 |
| 只有点击切换一种方式 | **Hold（按住）/ Toggle（点击）** 两种模式，设置面板即时切换 |
| 无参数面板 | 完整设置面板（= Flarial Zoom 设置项） |
| 无倍率指示 | 缩放时按钮上 / 屏幕下方显示当前倍率 `x2.3` |

## 安装

1. 打开 LeviLauncher → 模组管理 → 删除旧的 `BetterZoom` / `ZoomPlus` 导入。
2. 导入 `BetterZoom.levipack` 并启用。
3. **关闭 LeviLauncher 自带的 Zoom 模组**（“模组”列表里的 Zoom 开关），
   否则内置缩放与本模组会同时改写 FOV，出现双重缩放。
4. 从 LeviLauncher 启动 Minecraft（1.26.40.x）。进入游戏后右下角出现放大镜按钮。

## 使用

| 操作 | 效果 |
| --- | --- |
| **Hold 模式**：按住放大镜按钮 | 开始缩放（平滑缓入） |
| 按住按钮的同时，在按钮上**上下滑动**（同一根手指） | 上滑放大、下滑缩小，实时调整倍率 |
| **松开按钮** | 关闭缩放，视角平滑恢复 |
| **Toggle 模式**：轻点按钮 | 开启缩放（常亮），再次轻点关闭 |
| 缩放开启时，按钮上**拖动** | 调整倍率（不改变开关状态） |
| **屏幕上的任意手指**滑动 | 转视角（与原生一致，**任意手指数量/顺序、任意时刻**都正常） |

> **调倍率与转视角可同时进行**：转视角完全交给游戏原生触摸（所有屏幕手指原样透传，
> 游戏怎么转就怎么转）；调倍率只走缩放按钮上的滑动。按钮手指的滑动数据在**游戏触摸
> 桥钩子**里跟踪（它能同时看到所有手指，无论按钮是第一根还是第二根按下都有效），
> 并被从游戏触摸流中剔除——因此"按住按钮滑动调倍率"与"另一根手指转视角"互不抢占、
> 可同时进行。

> **转视角为什么任何顺序都正常**：本模组挂钩了游戏自己的触摸桥
> `GameActivityMotionEvent_fromJava`（libminecraftpe.so 的导出符号），在游戏输入系统
> 看到触摸之前把"按钮手指"从触摸事件里剔除（按 pointerId 匹配、指针数减一并压缩数组），
> 游戏只认得到转视角的手指——这正是 Flarial Client 的做法。
> 因此先按按钮再转视角、或先转视角再按按钮，都完全正常。
| 绑定 **Keybind** 后按键盘 | Hold：按住缩放 / Toggle：按下切换 |
| 缩放时 | 隐藏第一人称手、降低转向灵敏度（可关） |

> 触屏说明：Launcher 悬浮按钮是独立窗口，拿不到按钮上的滑动数据；若用自绘按钮却
> 不处理游戏侧触摸，按钮手指会以“幽灵指针”形式漏进游戏、把视角绑定在静止的按钮
> 手指上导致无法转向。因此本模组自绘按钮（同指滑动调倍率）+ 挂钩游戏触摸桥
> `GameActivityMotionEvent_fromJava` 按 pointerId 剔除按钮手指（任意顺序转视角），
> 两者缺一不可。按钮位置通过设置面板的 “Button X / Button Y” 调整（0–1000 的比例坐标，全屏任意位置）。

## 模组菜单参数（= Flarial Zoom 设置面板）

| 参数 | 类型 | 默认 | 说明 |
| --- | --- | --- | --- |
| Zoom Mode | Radio | Hold | `Hold` 按住缩放 / `Toggle` 点击切换 |
| Default Zoom Level | Slider | 10 | 缩放倍率（**1x–80x，设定值 = 放大倍数**，如 5 = 5 倍） |
| Use Scroll / Drag | Toggle | on | 允许滑动/滚轮调整倍率；**关闭后缩放倍率固定为 Default Zoom Level**（不可调整） |

> **鼠标滚轮**：缩放中滚轮调整倍率（上滚放大/下滚缩小）；非缩放时滚轮正常切换物品栏。

> **自定义按键图标**：把任意图片（PNG/JPEG/WebP，推荐正方形）命名为 `button_icon.png`
> 放进 `mods/BetterZoom/config/`，重启游戏后按钮就显示你的图标；删掉该文件即恢复默认放大镜。
| Zoom Sensitivity | Slider | 10 | 滑动每步调整的 FOV 量 |
| Disable Animation | Toggle | off | 关闭缩放动画（瞬间切换） |
| Animation Speed | Slider | 0.30 | 动画速度（越高越快） |
| Save Zoom Level | Toggle | on | 关闭后每次激活回到默认倍率 |
| Always Animate | Toggle | off | 未缩放时也平滑 FOV 变化（疾跑等） |
| Hide Hand | Toggle | on | 缩放时隐藏第一人称手 |
| Low Sensitivity | Toggle | on | 缩放时降低转向灵敏度 |
| Low Sensitivity Strength | Slider | 0.75 | 灵敏度降低程度 |
| Cinematic Camera | Toggle | off | 电影镜头模式 |
| Smoothing | Toggle | on | 转向平滑（依赖 Cinematic Camera） |
| Smoothness | Slider | 7.0 | 平滑强度 |
| Cinematic Bars | Toggle | off | 上下黑边（依赖 Cinematic Camera） |
| Cinematic Bar Height | Slider | 0.20 | 黑边高度占比 |
| Cinematic Bar Color | Color | #000000 | 黑边颜色 |
| Show Zoom Level | Toggle | on | 显示倍率指示器（屏幕下方 `x2.3`） |
| Hide HUD While Zoomed | Toggle | off | 缩放时隐藏游戏 HUD（快捷栏、准星等） |
| Keybind | Keybind | 空 | 可选键盘键位 |

> **界面语言**：模组菜单会自动跟随 LeviLauncher 的系统语言（中文环境显示中文，
> 英文环境显示英文），无需手动切换。
| Show Zoom Button | Toggle | on | 显示/隐藏放大镜按钮 |
| Button Size | Slider | 160 | 按钮大小（px，48–160） |
| Button X | Slider | 850 | 按钮横坐标（0=最左，1000=最右，覆盖全屏） |
| Button Y | Slider | 600 | 按钮纵坐标（0=最上，1000=最下，覆盖全屏） |
| Button Opacity | Slider | 1.0 | 按钮不透明度（0–1.0，0=完全透明，1.0=不透明） |
| Button Background Opacity | Slider | 1.0 | 按钮背景不透明度（0–1.0，只影响背景，不影响图标） |

参数修改即写回模组 `config/config.json`，下次启动自动恢复。

## 实现要点

- 生命周期：`PL_REGISTER_MOD` + `load/enable/disable/unload`（Levi 官方模版）。
- 菜单：`pl::modmenu::ModuleBuilder`（不写死 `modId`，由 preloader 归属当前模组）。
- 输入：`pl::input::registerTouchCallback` 拿到游戏视图的原始触摸流
  （返回 `true` 会消费事件、游戏与悬浮按钮都收不到，用于按钮点击与调倍率手势）。
- 屏幕尺寸：JNI 读取 `Resources.getSystem().getDisplayMetrics()`（全公开 API），
  用于按钮命中测试；失败时退化为按触摸坐标估算。
- 钩子（签名在 `libminecraftpe.so` 26.40.5 上逐一验证、各恰好命中一处）：
  - `LevelRendererPlayer::getFov` —— 缩放本体（指数缓出动画）
  - `LocalPlayer::applyTurnDelta` —— 低灵敏度 / 电影镜头平滑
  - `BaseOptionRegistry::getHideItemInHand` —— 隐藏手持物
  - `GameActivityMotionEvent_fromJava` —— 游戏触摸桥（导出符号，按名解析）；
    剔除缩放按钮手指，保证任意触摸顺序下转视角都正常（Flarial 同款机制）
- `libminecraftpe.so` 尚未加载时先挂 `dlopen` 钩子，游戏库加载后再解析签名并装钩。
- 覆盖层：`submitDrawCommands` 绘制按钮 / 倍率指示 / 黑边（负坐标锚点：
  `<= -9000` 右/下边缘、`<= -19000` 屏幕中心）。
- 依赖：`NEEDED libpreloader.so`（链接期使用 `lib/libpreloader-1.5.16.so` 解析符号，
  运行期解析到 launcher 自己的 preloader）；`--exclude-libs` 保证只导出
  `PLGetModRegistration`，与正常工作的参考模组一致。

## 构建

```bash
# 需要 clang-17/lld-17 与 Android NDK r28c sysroot（arm64）
NDK_SYSROOT=/path/to/ndk/sysroot ./build.sh        # 产出 build/libbetterzoom.so
python3 scripts/package_levipack.py --root .       # 产出 BetterZoom.levipack
```

## 故障排查

- **模组菜单里没有 “Zoom” 模块**：logcat 看 `adb logcat -s Preloader BetterZoom`，
  应有 `Mod menu module registered: true`；若为 false，看 “Rejected …” 原因。
- **钩子未生效（缩放无反应）**：`adb logcat -s BetterZoom` 应显示
  `GetFov=0x... ApplyTurnDelta=0x... HideItemInHand=0x...` 与
  `Game hooks installed: fov=.. turn=.. hand=.. touchBridge=..`；若 fov=false，
  检查 MC 版本是否确为 26.40.5（签名只验证过该版本）。
- **同时转向+调倍率排查**（关键日志，前若干次触发各打印几行）：
  - `TOUCH action=.. pointerId=.. x=.. y=..` —— 模组收到的触摸事件（重点看
    action=2 即 MOVE 时 pointerId 是否恒为 0）
  - `LATCHED adjust finger pointerId=..` —— 快速竖向滑动是否被识别为调倍率
  - `BRIDGE arg4=.. arg5=.. count=..` —— 游戏触摸桥是否被调到
  - `Stripping pointer id=.. (count .. -> ..)` —— 按钮手指是否被从游戏触摸流剔除
- **加载失败**：`Failed to load mod ...` / `dlopen failed: cannot locate symbol`
  时，确认 levipack 是本次新打包的（旧 v1.3.0 / ZoomPlus 需先删除）。
- **双重缩放**：确认已关闭 launcher 内置 Zoom。

## 已知取舍（相对 Flarial）

- Flarial 的 “Hide Modules”（隐藏其它 HUD）无法跨模组实现，省略。
- 鼠标滚轮调整未接入（触屏滑动 / 双指 / 按钮拖动已覆盖；Flarial 触屏版同样以
  滑动为主）。
- 打开 GUI（背包等）时缩放状态保留但 GUI 画面不缩放（与 OptiFine 一致）。
- 黑边高度按 1080p 折算为像素；手持物通道通过 `getFov` 的
  `enableVariableFOV` 位标志识别（固定 70° 通道），GUI 通道按 60° 值识别：
  缩放时手持物随动、GUI 不缩放，未缩放空闲时两者保持原样。

#!/usr/bin/env bash
# Build FlarialZoom (LeviLauncher native mod) for arm64-v8a.
#
# Requirements:
#   - clang-17 / lld-17 (NDK r28c's libc++ needs clang >= 16)
#   - Android NDK r28c sysroot extracted to $NDK_SYSROOT
#
# Usage:
#   NDK_SYSROOT=/path/to/sysroot ./build.sh
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT="${ROOT}/build"

CC="${CC:-clang-17}"
CXX="${CXX:-clang++-17}"
[ -x "$(command -v "$CXX" 2>/dev/null)" ] || CXX=clang++
[ -x "$(command -v "$CC" 2>/dev/null)" ] || CC=clang

NDK_SYSROOT="${NDK_SYSROOT:-${ANDROID_NDK_SYSROOT:-}}"
if [ -z "$NDK_SYSROOT" ] || [ ! -d "$NDK_SYSROOT/usr/include" ]; then
    echo "error: NDK sysroot not found. Set NDK_SYSROOT=/path/to/ndk/sysroot" >&2
    exit 1
fi

API="${API:-26}"
SYSROOT_INC="$NDK_SYSROOT/usr/include"
SYSROOT_LIB="$NDK_SYSROOT/usr/lib/aarch64-linux-android/$API"
SYSROOT_LIB_TOP="$NDK_SYSROOT/usr/lib/aarch64-linux-android"
LIBCXX_INC="$NDK_SYSROOT/usr/include/c++/v1"
ARCH_INC="$NDK_SYSROOT/usr/include/aarch64-linux-android"
RT_LIB="$NDK_SYSROOT/libclang_rt.builtins-aarch64-android.a"
UNWIND_LIB="$NDK_SYSROOT/libunwind.a"

TARGET="aarch64-linux-android${API}"

CXXFLAGS=(
    --target="$TARGET"
    --sysroot="$NDK_SYSROOT"
    -std=c++20
    -fPIC
    -Os
    -fvisibility=hidden
    -fvisibility-inlines-hidden
    -fno-rtti
    -fno-unwind-tables
    -fno-asynchronous-unwind-tables
    -fno-stack-protector
    -fmerge-all-constants
    -fno-exceptions
    -DJSON_NOEXCEPTION
    -ffunction-sections
    -fdata-sections
    -w
    -isystem"${LIBCXX_INC}"
    -isystem"${ARCH_INC}"
    -isystem"${SYSROOT_INC}"
    -I"${ROOT}/include"
    -I"${ROOT}/src"
    -I"${ROOT}/third_party" -I"${ROOT}/third_party/fmt"
    -DFMT_HEADER_ONLY
)

LDFLAGS=(
    --target="$TARGET"
    -shared
    -nostdlib
    -Wl,-z,max-page-size=16384
    -Wl,--hash-style=gnu
    -Wl,--gc-sections
    -Wl,--icf=all
    -Wl,--exclude-libs,ALL
    -L"${SYSROOT_LIB}"
    -L"${SYSROOT_LIB_TOP}"
    -L"${ROOT}/lib"
    -Wl,--no-as-needed -l:libpreloader-1.5.16.so -Wl,--as-needed
    "${UNWIND_LIB}"
)

mkdir -p "$OUT"
echo "==> compiling with $CXX (target $TARGET)"
$CXX "${CXXFLAGS[@]}" -c "${ROOT}/src/main.cpp"          -o "$OUT/main.o"
$CXX "${CXXFLAGS[@]}" -c "${ROOT}/src/ZoomConfig.cpp"    -o "$OUT/ZoomConfig.o"
$CXX "${CXXFLAGS[@]}" -c "${ROOT}/src/ZoomMod.cpp"       -o "$OUT/ZoomMod.o"

echo "==> linking"
$CXX "${LDFLAGS[@]}" \
    "${SYSROOT_LIB}/crtbegin_so.o" \
    "$OUT/main.o" "$OUT/ZoomConfig.o" "$OUT/ZoomMod.o" \
    -lc++_static -lc++abi -ldl -llog -lm -lc \
    "${RT_LIB}" \
    "${SYSROOT_LIB}/crtend_so.o" \
    -o "$OUT/libbetterzoom.so"

echo "==> done: $OUT/libbetterzoom.so"
file "$OUT/libbetterzoom.so"

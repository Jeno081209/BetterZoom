#pragma once

/**
 * @file Signatures.hpp
 * @brief Byte signatures for Minecraft Bedrock 26.40.5 (arm64-v8a).
 *
 * Every pattern below was verified against libminecraftpe.so extracted from
 * the 26.40.5 APK (arm64-v8a): each matches exactly one location.
 *
 *  - GetFov                    LevelRendererPlayer::getFov  float(void*, float, int)
 *  - LocalPlayerApplyTurnDelta LocalPlayer::applyTurnDelta  void(void*, Vec2*)
 *  - BaseOptionRegistryGetHideItemInHand                    bool(void*)
 */

namespace betterzoom {

inline constexpr const char *kGetFovPattern =
    "? ? ? FC ? ? ? 6D ? ? ? A9 ? ? ? F9 ? ? ? A9 ? ? ? 91 08 40 20 1E";

inline constexpr const char *kApplyTurnDeltaPattern =
    "? ? ? D1 ? ? ? FD ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? 91 "
    "56 D0 3B D5 F3 03 00 AA F4 03 01 AA ? ? ? F9 ? ? ? F8 ? ? ? F9 ? ? ? F9";

inline constexpr const char *kGetHideItemInHandPattern =
    "? ? ? A9 FD 03 00 91 ? ? ? F9 ? ? ? 52 ? ? ? F9 00 01 3F D6 "
    "? ? ? A8 ? ? ? 14 ? ? ? A9 FD 03 00 91 ? ? ? F9 ? ? ? 52 ? ? ? F9 00 01 3F D6 ? ? ? B4";

} // namespace betterzoom

// BaseOptionRegistry option getter for "hide HUD" (option id 48), the sibling
// of getHideItemInHand (option 49). Verified to match exactly once.
inline constexpr const char *kGetHideHudPattern =
    "FD 7B BF A9 FD 03 00 91 08 00 40 F9 01 06 80 52 08 09 40 F9 00 01 3F D6";
